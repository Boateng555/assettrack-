# AssetTrack - IT Asset Management Dashboard

A modern, responsive web application for managing IT asset handovers and tracking equipment inventory. Built with HTML, CSS (Tailwind), and JavaScript.

## Features

### 🎯 Dashboard Overview
- **Real-time Statistics**: View assets in stock, pending signatures, pending scans, and recent handovers
- **Interactive Cards**: Each stat card shows trends and additional context
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices

### 📋 Asset Handover Management
- **Digital Signatures**: Built-in signature pad for employee and IT representative signatures
- **Multiple Handover Modes**: Support for both digital (Screen Sign) and physical (Paper & Scan) processes
- **Status Tracking**: Real-time status updates (Completed, Pending Scan, etc.)
- **QR Code Generation**: Automatic QR code generation for handover documents

### 👥 Employee Management
- **Employee Profiles**: Complete employee information with department and contact details
- **Asset Assignment**: Track which assets are assigned to which employees
- **Department Organization**: Filter and organize by department

### 📦 Welcome Pack System
- **Automated Onboarding**: Generate welcome packs for new employees
- **Account Setup**: Configure user accounts with authentication methods
- **Resource Information**: Include IT helpdesk, HR contacts, and Wi-Fi access details
- **Delivery Options**: Multiple delivery methods (print, email, Teams chat)

### 🎨 Modern UI/UX
- **Dark Theme**: Professional dark theme optimized for IT environments
- **Responsive Navigation**: Collapsible mobile menu with smooth animations
- **Interactive Elements**: Hover effects, loading states, and smooth transitions
- **Accessibility**: ARIA labels and keyboard navigation support

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Tailwind CSS (via CDN)
- **Icons**: Lucide Icons
- **Signature Pad**: SignaturePad.js
- **QR Codes**: QRCode.js
- **Fonts**: Inter (Google Fonts)

## Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- No server setup required - runs entirely in the browser

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. The application will load with all features ready to use

### File Structure
```
assettrack/
├── index.html          # Main application file
├── script.js           # JavaScript functionality
└── README.md          # Project documentation
```

## Usage

### Dashboard Navigation
- **Dashboard**: Main overview with statistics and recent handovers
- **Employees**: Manage employee information and profiles
- **Assets**: Track and manage IT equipment inventory
- **Handovers**: Process and monitor asset handovers
- **Welcome Packs**: Generate onboarding materials

### Creating a New Handover
1. Click the "New Handover" button in the Recent Handovers section
2. Fill in employee and asset information
3. Choose handover mode (Screen Sign or Paper & Scan)
4. Collect digital signatures from both parties
5. Save the handover document

### Generating Welcome Packs
1. Navigate to the Welcome Packs section
2. Enter new employee information
3. Configure account setup and authentication
4. Select delivery options
5. Generate and distribute the welcome pack

## Key Features in Detail

### Signature Pad Integration
- **Dual Signatures**: Separate signature areas for employee and IT representative
- **Clear/Undo Functions**: Easy signature management with clear and undo options
- **Digital Storage**: Signatures are captured and stored digitally
- **Validation**: Checkbox confirmation for asset receipt acknowledgment

### QR Code System
- **Automatic Generation**: QR codes are automatically generated for each handover
- **Quick Access**: Scan QR codes to quickly access handover details
- **Custom Styling**: QR codes match the application's dark theme

### Responsive Design
- **Mobile-First**: Optimized for mobile devices with touch-friendly interfaces
- **Tablet Support**: Responsive layout that adapts to tablet screens
- **Desktop Experience**: Full-featured experience on desktop computers

## Browser Compatibility

- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+

## Customization

### Styling
The application uses Tailwind CSS classes. You can customize the appearance by:
- Modifying the CSS variables in the `<style>` section
- Adding custom Tailwind classes
- Overriding default styles

### Data
Currently, the application uses static data. To integrate with a backend:
- Replace static data with API calls
- Implement data persistence
- Add user authentication
- Set up database connections

### Features
Additional features can be added by:
- Extending the JavaScript functionality
- Adding new modal components
- Implementing additional data visualization
- Integrating with external services

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).

## Support

For support or questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation

---

**AssetTrack** - Streamlining IT asset management for modern organizations.

